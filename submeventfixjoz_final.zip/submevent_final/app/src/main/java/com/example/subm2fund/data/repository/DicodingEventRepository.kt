package com.example.subm2fund.data.repository
import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.example.subm2fund.data.entity.DicodingEventEntity
import com.example.subm2fund.data.room.DicodingEventDao
import com.example.subm2fund.data.response.EventResponse
import com.example.subm2fund.data.response.ListEventsItem
import com.example.subm2fund.data.retrofit.ApiService
import com.example.subm2fund.util.AppExecutors
import com.example.subm2fund.util.Result
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext

class DicodingEventRepository private constructor(
    private val api: ApiService,
    private val dicodingEventDao: DicodingEventDao,
    private val appExecutors: AppExecutors
) {

    fun getAllEvents(active: Int): LiveData<Result<List<DicodingEventEntity>>> = liveData {
        emit(Result.Loading)
        try {
            val response = api.getEvents(active)

            val data = response.listEvents
            val eventList = data.map { event ->
                val isFinished = active == 0
                val isUpcoming = active == 1
                val isFavourite = event.name.let {
                    dicodingEventDao.isEventFavourite(it)
                }
                DicodingEventEntity(
                    event.id,
                    event.name,
                    event.summary,
                    event.description,
                    event.imageLogo,
                    event.mediaCover,
                    event.category,
                    event.ownerName,
                    event.cityName,
                    event.quota,
                    event.registrants,
                    event.beginTime,
                    event.endTime,
                    event.link,
                    isUpcoming,
                    isFavourite,
                    isFinished
                )
            }

            dicodingEventDao.insertEvents(eventList)
            emit(Result.Success(eventList))

        } catch (e: Exception) {
            emit(Result.Error(e.message.toString()))
        }
    }

    suspend fun getEventByIdSync(eventId: Int): DicodingEventEntity? {
        return dicodingEventDao.getEventByIdSync(eventId)
    }

    suspend fun searchEvents(query: String): Result<List<ListEventsItem>> {
        return try {
            val response = api.searchEvents(query = query)
            if (response.isSuccessful) {
                val eventResponse = response.body()
                if (eventResponse != null && !eventResponse.error) {
                    Result.Success(eventResponse.listEvents)
                } else {
                    Result.Error(Exception("Failed fetching data...").toString())
                }
            } else {
                Result.Error(Exception("Network request failed").toString())
            }
        } catch (e: Exception) {
            Result.Error(e.toString())
        }
    }






    suspend fun addFavorite(event: DicodingEventEntity){

        withContext(appExecutors.diskIO.asCoroutineDispatcher()){
            dicodingEventDao.addFavoriteEvent(event)
        }
    }

    suspend fun removeFavorite(event:DicodingEventEntity){

        withContext(appExecutors.diskIO.asCoroutineDispatcher()){
            dicodingEventDao.deleteFavoriteEvent(event)
        }
    }

    fun getFavorite(): LiveData<List<DicodingEventEntity>>{
        return dicodingEventDao.getFavoriteEvent()
    }

    suspend fun getNearestEvent() : EventResponse? {
        val getEvent =  try {
            api.getUpdatedEvent(active = -1, limit = 1)
        } catch (e: Exception) {
            null
        }
        return getEvent
    }

    companion object {
        @Volatile
        private var instance: DicodingEventRepository? = null

        fun getInstance(
            apiService: ApiService,
            dicodingEventDao: DicodingEventDao,
            appExecutors: AppExecutors
        ): DicodingEventRepository =
            instance ?: synchronized(this) {
                instance ?: DicodingEventRepository(apiService, dicodingEventDao, appExecutors)
            }.also { instance = it }
    }

}
