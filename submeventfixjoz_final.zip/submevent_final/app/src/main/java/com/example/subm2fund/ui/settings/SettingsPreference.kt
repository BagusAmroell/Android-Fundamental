package com.example.subm2fund.ui.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore("settings")

class SettingsPreference private constructor(private val dataStore: DataStore<Preferences>){

    private val keyTheme = booleanPreferencesKey(THEME)
    private val keyNotification = booleanPreferencesKey(REMINDER)

    fun getThemeSetting() : Flow<Boolean>   {
        return dataStore.data.map{
            it[keyTheme] ?: false
        }
    }

    suspend fun setThemeSetting(isDarkMode : Boolean){
        dataStore.edit {
            it[keyTheme] = isDarkMode
        }
    }

    fun getReminderSetting() : Flow<Boolean> {
        return dataStore.data.map {
            it[keyNotification] ?: false
        }
    }

    suspend fun setReminderSetting(isActive : Boolean){
        dataStore.edit {
            it[keyNotification] = isActive
        }
    }

    companion object{
        @Volatile
        private var instance: SettingsPreference?= null
        const val THEME = "setting_theme"
        const val REMINDER = "setting_reminder"

        fun getInstance(dataStore: DataStore<Preferences>) : SettingsPreference =
            instance ?: synchronized(this){
                instance ?: SettingsPreference(dataStore)
            }.also { instance = it }
    }
}