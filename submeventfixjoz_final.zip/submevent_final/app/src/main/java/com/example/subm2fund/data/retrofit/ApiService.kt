package com.example.subm2fund.data.retrofit
import com.example.subm2fund.data.response.EventResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("events")
    suspend fun getEvents(@Query("active") active: Int): EventResponse
    @GET("events")
    suspend fun getUpdatedEvent(
        @Query("active") active: Int = -1,
        @Query("limit") limit: Int
    ): EventResponse

    @GET("events")
    suspend fun searchEvents(
        @Query("active") active: Int = -1,
        @Query("q") query: String
    ): Response<EventResponse>

}