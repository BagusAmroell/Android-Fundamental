package com.example.subm2fund.data.room

import androidx.room.Dao
import androidx.room.Query
import androidx.lifecycle.LiveData
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Update
import com.example.subm2fund.data.entity.DicodingEventEntity

@Dao
interface DicodingEventDao {

    @Query("SELECT * FROM event WHERE id = :eventId")
    suspend fun getEventByIdSync(eventId: Int): DicodingEventEntity?//

    @Query("SELECT * FROM event WHERE id = :eventId")
    fun getEventById(eventId: String): LiveData<DicodingEventEntity>//

    @Query("SELECT * FROM event where isFavourite = 1")
    fun getFavoriteEvent(): LiveData<List<DicodingEventEntity>>

    @Query("SELECT EXISTS(SELECT * FROM event WHERE isFavourite = 1 AND name = :name)")
    suspend fun isEventFavourite(name: String) : Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(news: List<DicodingEventEntity>)

    @Delete
    suspend fun deleteFavoriteEvent(events: DicodingEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavoriteEvent(events: DicodingEventEntity)



}