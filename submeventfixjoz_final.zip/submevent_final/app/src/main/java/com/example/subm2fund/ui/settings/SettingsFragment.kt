package com.example.subm2fund.ui.settings

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreference
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import com.example.subm2fund.R
import com.example.subm2fund.databinding.FragmentSettingsBinding
import com.example.subm2fund.worker.Worker
import com.example.subm2fund.ui.viewModel.FactoryViewModel
import com.example.subm2fund.ui.viewModel.MainViewModel
import java.util.concurrent.TimeUnit

class SettingsFragment : PreferenceFragmentCompat() {
    private var _binding: FragmentSettingsBinding? = null
    private lateinit var viewModel : MainViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val factory : FactoryViewModel = FactoryViewModel.getInstance(requireContext())
        viewModel = ViewModelProvider(requireActivity(),factory)[MainViewModel::class.java]

        (activity as? AppCompatActivity)?.supportActionBar?.hide()

        val themeButton = findPreference<SwitchPreference>("keyTheme")
        val reminButton = findPreference<SwitchPreference>("keyRemin")

        viewModel.getThemeSetting().observe(viewLifecycleOwner){ isDark->
            themeButton?.isChecked = isDark
        }

        viewModel.getReminderSetting().observe(viewLifecycleOwner){ isActive ->
            reminButton ?.isChecked = isActive
        }

        themeButton?.setOnPreferenceChangeListener{ _, newValue ->
            val isDark = newValue as Boolean
            viewModel.setThemeSetting(isDark)
            setTheme(isDark)
            true
        }

        reminButton?.setOnPreferenceChangeListener { _, newValue ->
            val isEnable = newValue as Boolean
            viewModel.setReminderSetting(isEnable)
            if(isEnable){
                startPriodic()
            }else{
                WorkManager.getInstance(requireContext()).cancelUniqueWork(Worker.NOTIFICATION_ID.toString())
            }
            true
        }
    }

    private fun startPriodic() {
        val workRequest: WorkRequest = PeriodicWorkRequestBuilder<Worker>(1, TimeUnit.DAYS)
            .build()
        WorkManager.getInstance(requireContext()).enqueue(workRequest)
    }

    private fun setTheme(isDark: Boolean) {
        if (isDark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

        (activity as? AppCompatActivity)?.supportActionBar?.show()
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        addPreferencesFromResource(R.xml.preference)
    }


}