package com.example.subm2fund.injection

import android.content.Context
import com.example.subm2fund.data.room.DicodingEventDatabase
import com.example.subm2fund.data.retrofit.ApiConfig
import com.example.subm2fund.data.repository.DicodingEventRepository
import com.example.subm2fund.util.AppExecutors

object Injection {
    fun provideRepository(context: Context): DicodingEventRepository {
        val apiService = ApiConfig.apiService
        val database = DicodingEventDatabase.getInstance(context)
        val dao = database.eventDao()
        val appExecutors = AppExecutors()

        return DicodingEventRepository.getInstance(apiService, dao, appExecutors)
    }
}