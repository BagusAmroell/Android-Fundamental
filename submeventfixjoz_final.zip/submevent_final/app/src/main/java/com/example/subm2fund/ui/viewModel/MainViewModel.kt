package com.example.subm2fund.ui.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.subm2fund.data.entity.DicodingEventEntity
import com.example.subm2fund.ui.settings.SettingsPreference
import com.example.subm2fund.data.response.ListEventsItem
import com.example.subm2fund.data.repository.DicodingEventRepository
import kotlinx.coroutines.launch
import com.example.subm2fund.util.Result

class MainViewModel(
    private val preference: SettingsPreference,
    private val repository: DicodingEventRepository
) : ViewModel() {

    // LiveData untuk status loading
    private val _isLoadingUpcoming = MutableLiveData<Boolean>()
    val isLoadingUpcoming: LiveData<Boolean> = _isLoadingUpcoming

    private val _isLoadingFinished = MutableLiveData<Boolean>()
    val isLoadingFinished: LiveData<Boolean> = _isLoadingFinished

    private val _events = MutableLiveData<Result<DicodingEventEntity>>()
    val events: LiveData<Result<DicodingEventEntity>> = _events

    private val _searchResult = MutableLiveData<Result<List<ListEventsItem>>>()
    val searchResult: LiveData<Result<List<ListEventsItem>>> = _searchResult

    fun getThemeSetting(): LiveData<Boolean> {
        return preference.getThemeSetting().asLiveData()
    }

    fun setThemeSetting(isDarkMode: Boolean) {
        viewModelScope.launch {
            preference.setThemeSetting(isDarkMode)
        }
    }

    fun getReminderSetting(): LiveData<Boolean> {
        return preference.getReminderSetting().asLiveData()
    }

    fun setReminderSetting(isActive: Boolean) {
        viewModelScope.launch {
            preference.setReminderSetting(isActive)
        }
    }

    fun searchEvents(query: String) {
        _searchResult.value = Result.Loading

        viewModelScope.launch {
            try {
                val result = repository.searchEvents(query)
                _searchResult.value = when (result) {
                    is Result.Success -> Result.Success(result.data)
                    else -> result
                }
            } catch (e: Exception) {
                _searchResult.value = Result.Error(e.toString())
            }
        }
    }

    fun getEventByIdSync(eventId: Int) = viewModelScope.launch {
        try {
            _events.value = Result.Loading
            val eventData = repository.getEventByIdSync(eventId)

            if (eventData != null) {
                _events.value = Result.Success(eventData)
            } else {
                _events.value = Result.Error("Event not found")
            }
        } catch (_: Exception) {

        }
    }

    fun getUpcomingEvent(): LiveData<Result<List<DicodingEventEntity>>> {
        _isLoadingUpcoming.value = true
        return repository.getAllEvents(1).also {
            it.observeForever { result ->
                _isLoadingUpcoming.value = result is Result.Loading
            }
        }
    }

    fun getFinishedEvent(): LiveData<Result<List<DicodingEventEntity>>> {
        _isLoadingFinished.value = true
        return repository.getAllEvents(0).also {
            it.observeForever { result ->
                _isLoadingFinished.value = result is Result.Loading
            }
        }
    }

    fun getFavorite(): LiveData<List<DicodingEventEntity>> {
        return repository.getFavorite()
    }

    fun addFavoriteEvent(event: DicodingEventEntity) {
        viewModelScope.launch {
            repository.addFavorite(event)
        }
    }

    fun removeFavoriteEvent(event: DicodingEventEntity) {
        viewModelScope.launch {
            repository.removeFavorite(event)
        }
    }
}
