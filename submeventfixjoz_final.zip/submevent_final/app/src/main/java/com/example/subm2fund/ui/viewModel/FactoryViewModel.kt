package com.example.subm2fund.ui.viewModel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.subm2fund.ui.settings.SettingsPreference
import com.example.subm2fund.ui.settings.dataStore
import com.example.subm2fund.injection.Injection
import com.example.subm2fund.data.repository.DicodingEventRepository

class FactoryViewModel (
    private val preference: SettingsPreference,
    private val dicodingEventRepository: DicodingEventRepository
) :
    ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when{
            modelClass.isAssignableFrom(MainViewModel::class.java) ->{
                MainViewModel(preference,dicodingEventRepository) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class : ${modelClass.name}")
        }
    }

    companion object {
        @Volatile
        private var instance: FactoryViewModel? = null
        fun getInstance(context: Context): FactoryViewModel =
            instance ?: synchronized(this) {
                instance ?: FactoryViewModel(
                    SettingsPreference.getInstance(context.dataStore),
                    Injection.provideRepository(context)
                )
            }.also { instance = it }
    }
}